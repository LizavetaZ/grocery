let cart = document.querySelector('.cartimage')
let cartConnection = document.querySelector('.cartform')
let close = document.querySelector('.cart-close')
let totalCart = document.querySelector('.totalCart')
let resultSum = document.querySelector('.result')
let cartWindow = document.querySelector('.cart-window')
let view = document.querySelector('.view')
// resultSum.value = 0;

// totalCart.setAttribute('goods', '0')

// console.log(totalCart)

let arr = []
totalCart.textContent = arr.length


class ProductMain {
    constructor(src, id, parentSelector, classfield, nameProduct, oldPrice, newPrice) {
        this.src = src;
        this.id = id;
        this.parent = document.querySelector(parentSelector);
        this.classfield = classfield;
        this.nameProduct = nameProduct;
        this.oldPrice = oldPrice;
        this.newPrice = newPrice;
    }

    renderProduct() {
        const product = document.createElement('div');
        product.classList.add('product')
        product.innerHTML = `
        <div id="${this.id}" class="offer">
            <a class="product-classfield-button" href="#">${this.classfield}</a>
            <img src=${this.src} width="140px" height="140px">
            <p>${this.nameProduct}</p>
            <hr>
            <div class="prices">
                <a class="old-price" href="#"><s>${this.oldPrice}</s>USD</a>
                <a class="new-price" href="#">${this.newPrice}</a>
            </div>
            <div class="offer-btn">
                <button id="${this.id}" class="buy">КУПИТЬ</button>
            </div>

        </div>`
        this.parent.append(product);
    }

}




const renderView = () => {
    
        fetch('http://localhost:3000/products')
        .then(response => response.json())
        .then(data => {
            
            data.forEach(({ src, id, parentSelector, classfield, nameProduct, oldPrice, newPrice }) => {
                new ProductMain(
                    src,
                    id,
                    parentSelector,
                    classfield,
                    nameProduct,
                    oldPrice,
                    newPrice).renderProduct()
            })
            buyBottom()
        })
    }
    



class ProductCart {
    constructor(src, id, parentSelector, nameProduct, newPrice) {
        this.src = src;
        this.id = id;
        this.parent = document.querySelector('.cart-window');
        this.nameProduct = nameProduct;
        this.newPrice = newPrice;
    }

    renderCart() {
        const cartview = document.createElement('div');
        cartview.classList.add('cartview')
        cartview.innerHTML = `
        <div id="${this.id}" class="order">
            <img class="del" src="/images/delete.png" width="20px" height="20px">
            <img src=${this.src} width="70px" height="90px">
            <p class="nameProduct">${this.nameProduct}</p> 
            <div class="counter" data-price="${this.newPrice}">
	            <button class="counter__btn" data-direction="minus">-</button>
	            <input type="text" value="1" class="counter__value">
	            <button class="counter__btn" data-direction="plus">+</button>
                <input type="text" value="${this.newPrice}" class="counter__price">
            </div>
            
        </div>`
        this.parent.append(cartview);
        
        
    }
}

const renderCartView = (arrayCart, arrId) => {
    // let totalPrice = 0
    // resultSum.value = '' 
    // console.log(arrayCart)
    // if (arrayCart === undefined) {
    //     console.log('nonono')
    // }
    arrayCart.forEach(product => {
        if (arrId.find((item) => item === product.id)) {
            new ProductCart(
                product.src,
                product.id,
                product.parentSelector,
                product.nameProduct,
                product.newPrice).renderCart();
                
        }        
    })
    delButton()
    // totalPrice += parseFloat(product.newPrice.textContent).toFixed(2)
    //             console.log(totalPrice)
                
    // resultSum.value += totalPrice
    // resultSum.value = ''
    // finalSum(arrId, arrayCart)
}



const openCart = () => {

    cart.addEventListener('click', () => {
        cartConnection.classList.add('toggle-popup');
        cartWindow.innerHTML = ''
        fetch('http://localhost:3000/products')
            .then(response => response.json())
            .then(data => renderCartView(data, arr))
        console.log("dfghj")
    })
}


const buyBottom = () => {
    const buy = document.querySelectorAll('.buy')
    console.log(buy)
    buy.forEach(item => {   //здесь ли это должно быть, по-другому кнопка не срабатывала
        item.addEventListener('click', () => {
            item.setAttribute("disabled", "disabled")
            // console.log(item.parentElement.parentElement.id)
            arr.push(item.id)
            totalCart.textContent = arr.length
            console.log(arr)
        })
    })
}



const closeCart = () => {
    close.addEventListener('click', () => {
        cartConnection.classList.remove('toggle-popup');
    })
}


const counter = () => {
    // console.log('ere')
    cartWindow.addEventListener('click', (e) => {
        let target = e.target
        if (target.getAttribute('data-direction') === 'plus') {
            let dataPrice = target.parentElement.getAttribute('data-price')
            let valuePrice = target.parentElement.querySelector('.counter__value')
            let pricePrice = target.parentElement.querySelector('.counter__price')
            valuePrice.value++
            pricePrice.value = parseFloat(dataPrice * valuePrice.value).toFixed(2)
            resultSum.value += +pricePrice.value
            // valuePrice.setAttribute('value', valuePrice.value)
            arr.push(target.parentElement.parentElement.id)
            totalCart.textContent = arr.length
            console.log(target.parentElement.parentElement.id)
            console.log(arr)
        }
        if (target.getAttribute('data-direction') === 'minus') {
            let dataPrice = target.parentElement.getAttribute('data-price')
            let valuePrice = target.parentElement.querySelector('.counter__value')
            let pricePrice = target.parentElement.querySelector('.counter__price')
            if (valuePrice.value - 1 >= 0 ? valuePrice.value - 1 : 0) { //можно ли без цикла??
                valuePrice.value--
                pricePrice.value = parseFloat(dataPrice * valuePrice.value).toFixed(2)
                // arr = arr.filter( (item,pos) => arr.indexOf(item) == pos) //здесь удалит все id
                // arr.splice(arr[0], target.parentElement.parentElement.id)
                // arr.forEach((item, index) => {
                //     if(item === target.parentElement.parentElement.id ) {
                //         arr.splice(index, target.parentElement.parentElement.id)
                //         // console.log(arr[index])            
                //     }
                // })
                totalCart.textContent = arr.length
                console.log(arr)
            }
            // valuePrice.setAttribute('value', valuePrice.value)
            // console.log('2')
        }

    })
}

const delButton = () => {
    const del = document.querySelectorAll('.del')
    // console.log(del)
    del.forEach(item => {
        item.addEventListener('click', (e) => {
            let target = e.target
            arr = arr.filter(elem => elem !== target.parentElement.id)
            console.log(target.parentElement.id)
            totalCart.textContent = arr.length
            console.log(arr)
        })
        
    })
    renderCartView(data, arr)
}



const finalSum = (arr, product) => {
    
    let totatlPrice = 0
    arr.forEach(item => {
        
        if (item === product.id) {
            resultSum.value = 0
            totatlPrice += product.newPrice.value
            
        }
       
    })
    console.log('result')
    // resultSum.value = totatlPrice
    // resultSum.value = totatlPrice
}


// const viewAll = () => {
//     let index;
//     view.addEventListener('click', () => {
//         // while (index % 6 != 0) {
//         //     renderView()
//         // }
//         // index+6
//         console.log('опять не работает')
//     })
// }

renderView()
counter()
// viewAll()
openCart()
closeCart()
delButton()





